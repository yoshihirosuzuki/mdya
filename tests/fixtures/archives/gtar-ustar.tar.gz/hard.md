# Short

A plain document.
