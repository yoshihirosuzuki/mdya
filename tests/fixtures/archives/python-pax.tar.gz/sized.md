# Sized

Carries a pax size record.
